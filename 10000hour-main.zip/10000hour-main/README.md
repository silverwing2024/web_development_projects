# 10000hours
* 1만 시간의 법칙 사이트 리소스
* web 구동을 위해 index.html 파일을 앞으로 배치해두었습니다.
* https://paullabkorea.github.io/10000hour/ 에서 확인 가능합니다.
* 해당 제작 과정은 무료강의로 오픈이 되어 있습니다. https://inf.run/j2JD 에서 확인이 가능합니다.
